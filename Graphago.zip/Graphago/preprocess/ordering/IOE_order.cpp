#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <map>
#include <errno.h>
#include <sstream>
#include <algorithm>
#include <sys/time.h>
#include <queue>

#define factor 0.00001
#define ISORT 25

using namespace std;
typedef unsigned int vertex_t;
typedef unsigned long index_t;

struct vertex{
    vertex_t in_deg;
    vertex_t out_deg;
//   index_t index;
    vector<vertex_t> out_neighbor;
    vector<vertex_t> in_neighbor;
    vertex():in_deg(0),out_deg(0){}
};

string filename, new_filename;
vertex_t num_vertices;
vertex_t max_id;
struct vertex *vertices;
vertex_t *sorted_ID;
bool *visit;
vertex_t *Map_ID;
vertex_t *Old_ID;

void obtain_degree(){

      FILE *inf = fopen(filename.c_str(),"r");
    /*  if(inf == NULL)
      cout << "Could not load: " << filename << endl;
      assert(inf != NULL); */

      if (inf == NULL) {
                cout << "Could not open file: " << filename << " error: " <<
                strerror(errno) << endl;
            }
            assert(inf != NULL);

      size_t bytesread = 0;
      size_t linenum = 0;
      size_t numedges = 0;

      char s[1024];
      while(fgets(s,1024,inf) != NULL){
            linenum++;
            if(linenum % 10000000 == 0)
               cout << "Read " << linenum << " lines, " << bytesread/1024 << " KB" << endl;
            /* Fix Line */
            int len = (int)strlen(s)-1;
            if(s[len]=='\n')
                s[len] = 0;

            bytesread+=strlen(s);
            if(s[0] == '#') continue; //comment
            if(s[0] == '%') continue; //comment
            char delims[] = "\t, ";
            char *t;
            t = strtok(s, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }

            vertex_t source = atoi(t);

            t = strtok(NULL, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }
            vertex_t dest = atoi(t);
            if(source != dest) {
                vertices[dest].in_deg++;
                vertices[source].out_deg++;
                vertices[source].out_neighbor.push_back(dest);
                vertices[dest].in_neighbor.push_back(source);
                numedges++;
            }

      }
      fclose(inf);
      cout << "Finish reading "<<numedges<<" edges! Size:" << bytesread << endl;
}



bool cmp(vertex_t a, vertex_t b){

      return vertices[a].in_deg >vertices[b].in_deg;
}

/*void SortIDByActivity(){


        for(vertex_t i = 0; i < num_vertices; i++){

            sort(sorted_ID.begin(), sorted_ID.end());
        }
      cout << "Finish sorting ID!" << endl;

}*/

//template <class E, class BinPred>
void insertionSort(vertex_t* A, int n) {
    for (int i=0; i < n; i++) {
        vertex_t v = A[i];
        vertex_t* B = A + i;
        while (--B >= A && cmp(v,*B)) *(B+1) = *B;
        *(B+1) = v;
    }
}

//template <class E, class BinPred>
void quickSort(vertex_t* A, int n) {
    if (n < ISORT) insertionSort(A, n);
    else {
        vertex_t p = A[rand() % n]; // Random pivot
        vertex_t* L = A;   // below L are less than pivot
        vertex_t* M = A;   // between L and M are equal to pivot
        vertex_t* R = A+n-1; // above R are greater than pivot
        while (1) {
            while (!cmp(p,*M)) {
                if (cmp(*M,p)) swap(*M,*(L++));
                if (M >= R) break;
                M++;
            }
            while (cmp(p,*R)) R--;
            if (M >= R) break;
            swap(*M,*R--);
            if (cmp(*M,p)) swap(*M,*(L++));
            M++;
        }
        quickSort(A, (int) (L-A));
        quickSort(M, (int) (A+n-M)); // Exclude all elts that equal pivot
    }
}
 
void IOE_Order(){

	vertex_t New_ID = 0;
	queue<vertex_t> frontier;
	vertex_t source = sorted_ID[0];
	Map_ID[source] = New_ID;
        Old_ID[New_ID] = source;
        New_ID++;
        visit[source] = true;
        frontier.push(source);
        while(!frontier.empty()){

	   vertex_t *sorted_frontier;
	   int num_act = frontier.size();
	   sorted_frontier = new vertex_t[num_act];
	   for(int m = 0; m < num_act; m++){

	      sorted_frontier[m] = frontier.front();
              frontier.pop();
           }		   
          // vertex_t v = frontier.front();
	  // frontier.pop();
	   quickSort(sorted_frontier, (int)num_act);
	   for(int n = 0; n < num_act; n++){

	      vertex_t v = sorted_frontier[n];
	      for(vertex_t i = 0; i < vertices[v].out_neighbor.size(); i++){

	        vertex_t out_neb = vertices[v].out_neighbor[i];
	        if(!visit[out_neb]){
                  Map_ID[out_neb] = New_ID;
                  Old_ID[New_ID] = out_neb;
                  New_ID++;
                  visit[out_neb] = true;
		  frontier.push(out_neb);
                }

	     }
          }	      
        }
	for(vertex_t j = 0; j < num_vertices; j++){

	   if(visit[j] == false){

             Map_ID[j] = New_ID;
             Old_ID[New_ID] = j;
             New_ID++;
             visit[j] = true;
	   }	   
        }
	cout <<New_ID<< endl;
        cout << "Finish reordering!" << endl;
}

void Norder1(){

        vertex_t New_ID = 0;
        queue<vertex_t> frontier;
        vertex_t source = sorted_ID[0];
        Map_ID[source] = New_ID;
        Old_ID[New_ID] = source;
        New_ID++;
        visit[source] = true;
        frontier.push(source);
        while(!frontier.empty()){

           vertex_t v = frontier.front();
           frontier.pop();
           for(vertex_t i = 0; i < vertices[v].out_neighbor.size(); i++){

              vertex_t out_neb = vertices[v].out_neighbor[i];
              if(!visit[out_neb]){
                Map_ID[out_neb] = New_ID;
                Old_ID[New_ID] = out_neb;
                New_ID++;
                visit[out_neb] = true;
                frontier.push(out_neb);
            }

          }
        }
        for(vertex_t j = 0; j < num_vertices; j++){

           if(visit[j] == false){

             Map_ID[j] = New_ID;
             Old_ID[New_ID] = j;
             New_ID++;
             visit[j] = true;
           }
        }
        cout <<New_ID<< endl;
        cout << "Finish reordering!" << endl;
}


void Norder(){

	vertex_t New_ID = 0;
        for(vertex_t i =0; i < num_vertices - 1; i++){
	   
	   vertex_t src = sorted_ID[i];
	 /*  if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }*/
	   vector<vertex_t> frontier;
           for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
	//    frontier.push_back(out_neb);
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

         }

           for(vertex_t m = 0; m < vertices[src].out_neighbor.size(); m++){

		   vertex_t src1 = vertices[src].out_neighbor[m];
                   for(vertex_t n = 0; n < vertices[src1].out_neighbor.size(); n++){

		      vertex_t out_neb1 = vertices[src1].out_neighbor[n];     
                      if(!visit[out_neb1]){
                        Map_ID[out_neb1] = New_ID;
                        Old_ID[New_ID] = out_neb1;
                        New_ID++;
                        visit[out_neb1] = true;
                     }

            }
	 }
	 /*  for(vertex_t m = 0; m < frontier.size(); m++){

              vertex_t src1 = frontier[m];
	      for(vertex_t n = 0; n < vertices[src1].out_neighbor.size(); n++){

		 vertex_t out_neb1 = vertices[src1].out_neighbor[n];     
                 if(!visit[out_neb1]){
                   Map_ID[out_neb1] = New_ID;
                   Old_ID[New_ID] = out_neb1;
                   New_ID++;
                   visit[out_neb1] = true;
                  }

	    }	      

       }*/		   
	   
    }
    cout <<New_ID<< endl;
    cout << "Finish reordering!" << endl;
}

void Reordering_traverse(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void GenerateNewFile(){

    new_filename = filename + "_reorder";
     FILE* graph_data = fopen(new_filename.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename << endl;
		exit(1);
	}

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

	}

	fclose(graph_data);
	cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}

int main(int argc, char **argv){

    printf("Input: ./exe initial_file number_of_vertices\n");
    if(argc != 3){
		printf("Input format wrong\n");
		exit(-1);
	}
    filename = argv[1];
    num_vertices = atoi(argv[2]);

    struct timeval time_st, time_en, time_st1, time_en1;

    //unsigned * vertex_index;
    //int * in_degree;
    //int * out_degree;

    //vertex_index = new unsigned[num_vertices];
    //in_degree = new int[num_vertices];
    //out_degree = new int[num_vertices];


    vertices = new struct vertex[num_vertices];


    obtain_degree();

   /* for(vertex_t i =0; i < num_vertices; i++){

        for(vertex_t j = 0; j < vertices[i].out_neighbor.size(); j++){

            vertex_t dst = vertices[i].out_neighbor[j];
            cout<<i<<"->"<<dst<<endl;
        }
    } */

    sorted_ID = new vertex_t[num_vertices];

    for(vertex_t i = 0; i < num_vertices; i++)
        sorted_ID[i] = i;

   gettimeofday(&time_st, NULL);

  // SortIDByActivity();

   quickSort(sorted_ID, (int)num_vertices);

   /*for(vertex_t i =0; i < num_vertices; i++)

        cout<<sorted_ID[i]<<" "<<activity[sorted_ID[i]]<<endl;*/

    visit = new bool[num_vertices];

    for(vertex_t j = 0; j < num_vertices; j++)
        visit[j] = false;

    Map_ID = new vertex_t[num_vertices];
    Old_ID = new vertex_t[num_vertices];

    IOE_Order();

    gettimeofday(&time_en, NULL);
    float timeuse = 1000000 * (time_en.tv_sec - time_st.tv_sec) + time_en.tv_usec - time_st.tv_usec;
    timeuse /= 1000000;
    cout<<"It take "<<timeuse<<" seconds to ioe-order!"<<endl;

    // count the time of Norder

    gettimeofday(&time_st1, NULL);

    quickSort(sorted_ID, (int)num_vertices);


    for(vertex_t j = 0; j < num_vertices; j++)
        visit[j] = false;

    Norder1();

    cout<<"old to new"<<endl;
    for(vertex_t i =0; i < 10; i++)

    cout<<i<<"->"<<Map_ID[i]<<endl;

    cout<<"new to old"<<endl;
    for(vertex_t i =0; i < 10; i++)

    cout<<i<<"->"<<Old_ID[i]<<endl;


    gettimeofday(&time_en1, NULL);
    timeuse = 1000000 * (time_en1.tv_sec - time_st1.tv_sec) + time_en1.tv_usec - time_st1.tv_usec;
    timeuse /= 1000000;
    cout<<"It take "<<timeuse<<" seconds to norder!"<<endl;


    GenerateNewFile();

    return 0;
}
