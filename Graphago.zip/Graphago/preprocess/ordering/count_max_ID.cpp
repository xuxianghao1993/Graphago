#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <map>
#include <errno.h>
#include <sstream>
#include <algorithm>

#define factor 0.00001
#define ISORT 25

using namespace std;
typedef unsigned long vertex_t;
typedef unsigned long index_t;

struct vertex{
    vertex_t in_deg;
    vertex_t out_deg;
    index_t index;
    vector<vertex_t> out_neighbor;
    vector<vertex_t> in_neighbor;
    vertex():in_deg(0),out_deg(0),index(0){}
};

struct edge{
    vertex_t st;
    vertex_t en;
    edge():st(0), en(0){}
};

string filename, new_filename;
vertex_t num_vertices;
vertex_t max_id;
vector<struct edge> *edgelist;
struct vertex *vertices;
float *activity;
vertex_t *sorted_ID;
map<vertex_t, vertex_t> *MapNewID;
bool *visit;
vertex_t *Map_ID;
vertex_t *Old_ID;

void obtain_degree(){

      FILE *inf = fopen(filename.c_str(),"r");
    /*  if(inf == NULL)
      cout << "Could not load: " << filename << endl;
      assert(inf != NULL); */

      if (inf == NULL) {
                cout << "Could not open file: " << filename << " error: " <<
                strerror(errno) << endl;
            }
            assert(inf != NULL);

      size_t bytesread = 0;
      size_t linenum = 0;
      size_t numedges = 0;

      char s[1024];
      while(fgets(s,1024,inf) != NULL){
            linenum++;
            if(linenum % 10000000 == 0)
               cout << "Read " << linenum << " lines, " << bytesread/1024 << " KB" << endl;
            /* Fix Line */
            int len = (int)strlen(s)-1;
            if(s[len]=='\n')
                s[len] = 0;

            bytesread+=strlen(s);
            if(s[0] == '#') continue; //comment
            if(s[0] == '%') continue; //comment
            char delims[] = "\t, ";
            char *t;
            t = strtok(s, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }

            vertex_t source = atoi(t);
            t = strtok(NULL, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }
            vertex_t dest = atoi(t);
            if(source != dest){ 
		numedges++;
                max_id = max(max(source, dest), max_id);
	   }

      }
      fclose(inf);
      cout << "Finish reading "<<numedges<<" edges! Size:" << bytesread <<" Max Veretx ID:" <<max_id<< endl;
}

void compute_activity(){

      for(vertex_t v = 0; v < num_vertices; v++){

        vertex_t max_indeg = 0;
        for(vertex_t i = 0; i < vertices[v].in_neighbor.size(); i++){

            vertex_t neb = vertices[v].in_neighbor[i];
            if(max_indeg < vertices[neb].in_deg)
               max_indeg = vertices[neb].in_deg;

        }
        if(vertices[v].out_deg == 0)
           activity[v] = -1;
        else if(vertices[v].in_deg == 0)
            activity[v] = 0;
            else
               activity[v] = vertices[v].in_deg * max_indeg * factor;

      }
      cout << "Finish computing activity!" << endl;

}

bool cmp(vertex_t a, vertex_t b){

      return activity[a] > activity[b];
}

/*void SortIDByActivity(){


        for(vertex_t i = 0; i < num_vertices; i++){

            sort(sorted_ID.begin(), sorted_ID.end());
        }
      cout << "Finish sorting ID!" << endl;

}*/

//template <class E, class BinPred>
void insertionSort(vertex_t* A, int n) {
    for (int i=0; i < n; i++) {
        vertex_t v = A[i];
        vertex_t* B = A + i;
        while (--B >= A && cmp(v,*B)) *(B+1) = *B;
        *(B+1) = v;
    }
}

//template <class E, class BinPred>
void quickSort(vertex_t* A, int n) {
    if (n < ISORT) insertionSort(A, n);
    else {
        vertex_t p = A[rand() % n]; // Random pivot
        vertex_t* L = A;   // below L are less than pivot
        vertex_t* M = A;   // between L and M are equal to pivot
        vertex_t* R = A+n-1; // above R are greater than pivot
        while (1) {
            while (!cmp(p,*M)) {
                if (cmp(*M,p)) swap(*M,*(L++));
                if (M >= R) break;
                M++;
            }
            while (cmp(p,*R)) R--;
            if (M >= R) break;
            swap(*M,*R--);
            if (cmp(*M,p)) swap(*M,*(L++));
            M++;
        }
        quickSort(A, (int) (L-A));
        quickSort(M, (int) (A+n-M)); // Exclude all elts that equal pivot
    }
}

void Reordering_traverse(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_activity(){

    for(vertex_t i =0; i < num_vertices; i++){

        Map_ID[sorted_ID[i]] = i;
        Old_ID[i] = sorted_ID[i];

    }

    cout << "Finish reordering!" << endl;

}

void GenerateNewFile(){

    new_filename = filename + "_reorder";
     FILE* graph_data = fopen(new_filename.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename << endl;
		exit(1);
	}

    size_t num_edges = 0;
	vertex_t new_src, old_src, old_dst, new_dst;

	for(vertex_t i = 0; i < num_vertices; i++){

        old_src = sorted_ID[i];
        new_src = Map_ID[old_src];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%ld %ld\n",new_src,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

	}

	fclose(graph_data);
	cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}

void Test(){

    string new_filename_test = filename + "_test";
    FILE* graph_data = fopen(new_filename_test.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename_test << endl;
		exit(1);
	}

    for(vertex_t i = 0; i <34681189; i++)

        fprintf(graph_data, "%ld %ld\n",i,i+1);

}

int main(int argc, char **argv){

    printf("Input: ./exe initial_file\n");
    if(argc != 2){
		printf("Input format wrong\n");
		exit(-1);
	}
    filename = argv[1];
    obtain_degree();

    return 0;
}
