#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <map>
#include <errno.h>
#include <sstream>
#include <algorithm>
#include <sys/time.h>

#define factor 0.00001
#define ISORT 25

using namespace std;
typedef unsigned int vertex_t;
typedef unsigned long index_t;

struct vertex{
    vertex_t in_deg;
    vertex_t out_deg;
//   index_t index;
    vector<vertex_t> out_neighbor;
    vector<vertex_t> in_neighbor;
    vertex():in_deg(0),out_deg(0){}
};

string filename, new_filename_trav, new_filename_actv, new_filename_hyb, new_filename_csr, beg_filename;
vertex_t num_vertices;
vertex_t max_id;
struct vertex *vertices;
float *activity;
vertex_t *sorted_ID;
bool *visit;
vertex_t *Map_ID;
vertex_t *Old_ID;
index_t *beg_pos;

void obtain_degree(){

      FILE *inf = fopen(filename.c_str(),"r");
    /*  if(inf == NULL)
      cout << "Could not load: " << filename << endl;
      assert(inf != NULL); */

      if (inf == NULL) {
                cout << "Could not open file: " << filename << " error: " <<
                strerror(errno) << endl;
            }
            assert(inf != NULL);

      size_t bytesread = 0;
      size_t linenum = 0;
      size_t numedges = 0;

      char s[1024];
      while(fgets(s,1024,inf) != NULL){
            linenum++;
            if(linenum % 10000000 == 0)
               cout << "Read " << linenum << " lines, " << bytesread/1024 << " KB" << endl;
            /* Fix Line */
            int len = (int)strlen(s)-1;
            if(s[len]=='\n')
                s[len] = 0;

            bytesread+=strlen(s);
            if(s[0] == '#') continue; //comment
            if(s[0] == '%') continue; //comment
            char delims[] = "\t, ";
            char *t;
            t = strtok(s, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }

            vertex_t source = atoi(t);

            t = strtok(NULL, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }
            vertex_t dest = atoi(t);
            if(source != dest) {
                vertices[dest].in_deg++;
                vertices[source].out_deg++;
                vertices[source].out_neighbor.push_back(dest);
                vertices[dest].in_neighbor.push_back(source);
                numedges++;
            }

      }
      fclose(inf);
      cout << "Finish reading "<<numedges<<" edges! Size:" << bytesread << endl;
}

void compute_activity(){

      for(vertex_t v = 0; v < num_vertices; v++){

        vertex_t max_indeg = 0;
        for(vertex_t i = 0; i < vertices[v].in_neighbor.size(); i++){

            vertex_t neb = vertices[v].in_neighbor[i];
            if(max_indeg < vertices[neb].in_deg)
               max_indeg = vertices[neb].in_deg;

        }
        if(vertices[v].out_deg == 0)
           activity[v] = -1;
        else if(vertices[v].in_deg == 0)
            activity[v] = 0;
            else
               activity[v] = vertices[v].in_deg * max_indeg * factor;

      }
      cout << "Finish computing activity!" << endl;

}



bool cmp(vertex_t a, vertex_t b){

      return activity[a] > activity[b];
}

/*void SortIDByActivity(){


        for(vertex_t i = 0; i < num_vertices; i++){

            sort(sorted_ID.begin(), sorted_ID.end());
        }
      cout << "Finish sorting ID!" << endl;

}*/

//template <class E, class BinPred>
void insertionSort(vertex_t* A, int n) {
    for (int i=0; i < n; i++) {
        vertex_t v = A[i];
        vertex_t* B = A + i;
        while (--B >= A && cmp(v,*B)) *(B+1) = *B;
        *(B+1) = v;
    }
}

//template <class E, class BinPred>
void quickSort(vertex_t* A, int n) {
    if (n < ISORT) insertionSort(A, n);
    else {
        vertex_t p = A[rand() % n]; // Random pivot
        vertex_t* L = A;   // below L are less than pivot
        vertex_t* M = A;   // between L and M are equal to pivot
        vertex_t* R = A+n-1; // above R are greater than pivot
        while (1) {
            while (!cmp(p,*M)) {
                if (cmp(*M,p)) swap(*M,*(L++));
                if (M >= R) break;
                M++;
            }
            while (cmp(p,*R)) R--;
            if (M >= R) break;
            swap(*M,*R--);
            if (cmp(*M,p)) swap(*M,*(L++));
            M++;
        }
        quickSort(A, (int) (L-A));
        quickSort(M, (int) (A+n-M)); // Exclude all elts that equal pivot
    }
}

void Reordering_hybrid(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices/100; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
      }
     for(vertex_t j = 0; j < num_vertices; j++){

       vertex_t src_1 = sorted_ID[j];
       if(!visit[src_1]){
           Map_ID[src_1] = New_ID;
           Old_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
        }
	for(vertex_t v = 0; v < vertices[src_1].out_neighbor.size(); v++){

           vertex_t out_neb = vertices[src_1].out_neighbor[v];
           if(!visit[out_neb]){
            Map_ID[out_neb] = New_ID;
            Old_ID[New_ID] = out_neb;
            New_ID++;
            visit[out_neb] = true;
        }

      }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_traverse(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_activity(){

    for(vertex_t i =0; i < num_vertices; i++){

        Map_ID[sorted_ID[i]] = i;
        Old_ID[i] = sorted_ID[i];

    }

    cout << "Finish reordering!" << endl;

}

void GenerateNewFile_trav(){

    new_filename_trav = filename + "_reorder_trav";
     FILE* graph_data = fopen(new_filename_trav.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename_trav << endl;
		exit(1);
	}

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

	}

	fclose(graph_data);
	cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}

void GenerateNewFile_act(){

    new_filename_actv = filename + "_reorder_actv";
     FILE* graph_data = fopen(new_filename_actv.c_str(), "w");
     if(graph_data == NULL){
                cout << "can not open file " << new_filename_actv << endl;
                exit(1);
        }

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

        }

        fclose(graph_data);
        cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}

void GenerateNewFile_hyb(){

    new_filename_hyb = filename + "_reorder_hyb";
     FILE* graph_data = fopen(new_filename_hyb.c_str(), "w");
     if(graph_data == NULL){
                cout << "can not open file " << new_filename_hyb << endl;
                exit(1);
        }

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

        }

        fclose(graph_data);
        cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}



void GenerateNewFile_CSR(){

     new_filename_csr = filename + "_reorder_csr";
     FILE* graph_data = fopen(new_filename_csr.c_str(), "wb");
     if(graph_data == NULL){
                cout << "can not open file " << new_filename_csr << endl;
                exit(1);
        }
     beg_filename = filename + "_beg";
     FILE* beg_file = fopen(beg_filename.c_str(), "wb");
     if(beg_file == NULL){
                cout << "can not open file " << beg_filename << endl;
                exit(1);
        }


    size_t num_edges = 0;
    size_t pos = 0;
    vertex_t new_src, old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = sorted_ID[i];
        new_src = Map_ID[old_src];
	beg_pos[new_src] = pos;
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
	    fwrite(&new_dst, sizeof(vertex_t), 1, graph_data);
	 //   fprintf(graph_data, "%ld %ld\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;
	    pos++;

        }

     }

     fclose(graph_data);
     fwrite(beg_pos, sizeof(index_t), num_vertices, beg_file);
     fclose(beg_file);
     cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;
     cout<<"size of vertex_t:"<< sizeof(vertex_t) << " size of index_t:"<<sizeof(index_t)<<endl;

}


/*void Test(){

    string new_filename_test = filename + "_test";
    FILE* graph_data = fopen(new_filename_test.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename_test << endl;
		exit(1);
	}

    for(vertex_t i = 0; i <34681189; i++)

        fprintf(graph_data, "%d %d\n",i,i+1);

}*/

int main(int argc, char **argv){

    printf("Input: ./exe initial_file number_of_vertices\n");
    if(argc != 3){
		printf("Input format wrong\n");
		exit(-1);
	}
    filename = argv[1];
    num_vertices = atoi(argv[2]);

    struct timeval time_st, time_en, time_st1, time_en1, time_st2, time_en2, time_st3, time_en3;
    //unsigned * vertex_index;
    //int * in_degree;
    //int * out_degree;

    //vertex_index = new unsigned[num_vertices];
    //in_degree = new int[num_vertices];
    //out_degree = new int[num_vertices];


    vertices = new struct vertex[num_vertices];


    obtain_degree();

   /* for(vertex_t i =0; i < num_vertices; i++){

        for(vertex_t j = 0; j < vertices[i].out_neighbor.size(); j++){

            vertex_t dst = vertices[i].out_neighbor[j];
            cout<<i<<"->"<<dst<<endl;
        }
    } */


    activity = new float[num_vertices];

    compute_activity();

 /*   for(vertex_t i =0; i < num_vertices; i++)

        cout<<activity[i]<<endl; */
    sorted_ID = new vertex_t[num_vertices];

    for(vertex_t i = 0; i < num_vertices; i++)
        sorted_ID[i] = i;

//   SortIDByActivity();

   gettimeofday(&time_st, NULL);

   quickSort(sorted_ID, (int)num_vertices);

   gettimeofday(&time_en, NULL);
   float timeuse = 1000000 * (time_en.tv_sec - time_st.tv_sec) + time_en.tv_usec - time_st.tv_usec;
   timeuse /= 1000000;
   cout<<"It take "<<timeuse<<" seconds to generate the sorted_ID!"<<endl;


   /*for(vertex_t i =0; i < num_vertices; i++)

        cout<<sorted_ID[i]<<" "<<activity[sorted_ID[i]]<<endl;*/
    gettimeofday(&time_st1, NULL);

    visit = new bool[num_vertices];

    for(vertex_t j = 0; j < num_vertices; j++)
        visit[j] = false;

    Map_ID = new vertex_t[num_vertices];
    Old_ID = new vertex_t[num_vertices];

    Reordering_traverse();

  /*  cout<<"old to new"<<endl;
    for(vertex_t i =0; i < num_vertices; i++)

        cout<<i<<"->"<<Map_ID[i]<<endl;

    cout<<"new to old"<<endl;
    for(vertex_t i =0; i < num_vertices; i++)

        cout<<i<<"->"<<Old_ID[i]<<endl;
    cout<<endl;*/

 /*   beg_pos = new index_t[num_vertices];

    for(vertex_t beg = 0; beg < num_vertices; beg++)
        beg_pos[beg] = 0;*/

    gettimeofday(&time_en1, NULL);
    float timeuse1 = 1000000 * (time_en1.tv_sec - time_st1.tv_sec) + time_en1.tv_usec - time_st1.tv_usec;
    timeuse1 /= 1000000;
    cout<<"It take "<<timeuse1<<" seconds to traverse reorder!"<<endl;

    GenerateNewFile_trav();
  //  Test();
    
    gettimeofday(&time_st2, NULL);
    Reordering_activity();
    gettimeofday(&time_en2, NULL);
    float timeuse2 = 1000000 * (time_en2.tv_sec - time_st2.tv_sec) + time_en2.tv_usec - time_st2.tv_usec;
    timeuse2 /= 1000000;
    cout<<"It take "<<timeuse2<<" seconds to activity reorder!"<<endl;
    GenerateNewFile_act();

    gettimeofday(&time_st3, NULL);
    for(vertex_t j = 0; j < num_vertices; j++)
        visit[j] = false;
    Reordering_hybrid();
    gettimeofday(&time_en3, NULL);
    float timeuse3 = 1000000 * (time_en3.tv_sec - time_st3.tv_sec) + time_en3.tv_usec - time_st3.tv_usec;
    timeuse3 /= 1000000;
    cout<<"It take "<<timeuse3<<" seconds to hybrid reorder!"<<endl;

    GenerateNewFile_hyb();


    return 0;
}
