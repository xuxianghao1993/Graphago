#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <map>
#include <errno.h>
#include <sstream>
#include <algorithm>
#include <sys/time.h>

#define factor 0.00001
#define ISORT 25

using namespace std;
typedef unsigned int vertex_t;
typedef unsigned long index_t;

struct vertex{
    vertex_t in_deg;
    vertex_t out_deg;
//   index_t index;
    vector<vertex_t> out_neighbor;
    vector<vertex_t> in_neighbor;
    vertex():in_deg(0),out_deg(0){}
};

string filename, new_filename, beg_filename;
vertex_t num_vertices, num_edges;
vertex_t max_id;
struct vertex *vertices;
float *activity;
vertex_t *sorted_ID;
vertex_t *balanced_sorted_ID;
bool *visit;
bool *newid_visit;
vertex_t *Map_ID;
vertex_t *Old_ID;
index_t *beg_pos;

void obtain_degree(){

      FILE *inf = fopen(filename.c_str(),"r");
    /*  if(inf == NULL)
      cout << "Could not load: " << filename << endl;
      assert(inf != NULL); */

      if (inf == NULL) {
                cout << "Could not open file: " << filename << " error: " <<
                strerror(errno) << endl;
            }
            assert(inf != NULL);

      size_t bytesread = 0;
      size_t linenum = 0;
      size_t numedges = 0;

      char s[1024];
      while(fgets(s,1024,inf) != NULL){
            linenum++;
            if(linenum % 10000000 == 0)
               cout << "Read " << linenum << " lines, " << bytesread/1024 << " KB" << endl;
            /* Fix Line */
            int len = (int)strlen(s)-1;
            if(s[len]=='\n')
                s[len] = 0;

            bytesread+=strlen(s);
            if(s[0] == '#') continue; //comment
            if(s[0] == '%') continue; //comment
            char delims[] = "\t, ";
            char *t;
            t = strtok(s, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }

            vertex_t source = atoi(t);

            t = strtok(NULL, delims);
            if(t == NULL){
            cout << "ERROR: " << " input file is not in right format. " << endl
                  << "Expecting \"<from>\t<to>\". "
                  << "Current line: \"" << s << "\"\n";
            assert(false);
          }
            vertex_t dest = atoi(t);
            if(source != dest) {
                vertices[dest].in_deg++;
                vertices[source].out_deg++;
                vertices[source].out_neighbor.push_back(dest);
                vertices[dest].in_neighbor.push_back(source);
                numedges++;
            }

      }
      fclose(inf);
      num_edges = numedges;
      cout << "Finish reading "<<num_edges<<" edges! Size:" << bytesread << endl;
}

void compute_activity(){

      for(vertex_t v = 0; v < num_vertices; v++){

        vertex_t max_indeg = 0;
        for(vertex_t i = 0; i < vertices[v].in_neighbor.size(); i++){

            vertex_t neb = vertices[v].in_neighbor[i];
            if(max_indeg < vertices[neb].in_deg)
               max_indeg = vertices[neb].in_deg;

        }
        if(vertices[v].out_deg == 0)
           activity[v] = -1;
        else if(vertices[v].in_deg == 0)
            activity[v] = 0;
            else
               activity[v] = vertices[v].in_deg * max_indeg * factor;

      }
      cout << "Finish computing activity!" << endl;

}



bool cmp(vertex_t a, vertex_t b){

      return activity[a] > activity[b];
}

/*void SortIDByActivity(){


        for(vertex_t i = 0; i < num_vertices; i++){

            sort(sorted_ID.begin(), sorted_ID.end());
        }
      cout << "Finish sorting ID!" << endl;

}*/

//template <class E, class BinPred>
void insertionSort(vertex_t* A, int n) {
    for (int i=0; i < n; i++) {
        vertex_t v = A[i];
        vertex_t* B = A + i;
        while (--B >= A && cmp(v,*B)) *(B+1) = *B;
        *(B+1) = v;
    }
}

//template <class E, class BinPred>
void quickSort(vertex_t* A, int n) {
    if (n < ISORT) insertionSort(A, n);
    else {
        vertex_t p = A[rand() % n]; // Random pivot
        vertex_t* L = A;   // below L are less than pivot
        vertex_t* M = A;   // between L and M are equal to pivot
        vertex_t* R = A+n-1; // above R are greater than pivot
        while (1) {
            while (!cmp(p,*M)) {
                if (cmp(*M,p)) swap(*M,*(L++));
                if (M >= R) break;
                M++;
            }
            while (cmp(p,*R)) R--;
            if (M >= R) break;
            swap(*M,*R--);
            if (cmp(*M,p)) swap(*M,*(L++));
            M++;
        }
        quickSort(A, (int) (L-A));
        quickSort(M, (int) (A+n-M)); // Exclude all elts that equal pivot
    }
}

void Balanced_highly_active_vertices(){

    vertex_t New_ID = 0;
    vertex_t sub_vertices = num_vertices/4 + 1;
    vertex_t num_active = num_vertices/100 + 1;
    vertex_t sub_active = num_active/4 + 1;
    index_t sub_edges = num_edges/4 + 1;
    index_t num_highly_active_edges;

/*    for(vertex_t v = 0; v < num_active; v++)

       num_highly_active_edges += vertices[v].out_deg;*/

    int p = 0;
    int j = num_active;
  //  index_t sub_active_edges = num_highly_active_edges/4;

    for(p; p < 4; p++){

     index_t partition_edges = 0;	    
     for(vertex_t i = sub_active * p; i < sub_active * (p+1); i++){
      
	vertex_t src = sorted_ID[i];
/*      if(visit[src])
           std::cout<<"src: "<<src<<" new id: "<<Map_ID[src]<<std::endl;*/
        if(!visit[src]){
           balanced_sorted_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
	   partition_edges += vertices[src].out_deg; 
        }
//	i++;
  /*      if(p < 3 && partition_edges >= sub_active_edges){

           std::cout<<"cnmlgb2!"<<std::endl;
           std::cout<<"new ID: "<<New_ID<<std::endl;
           break;
       }*/

      }

     cout << "num of highly active edges in partition "<<p<<": "<<partition_edges<< endl;

     std::cout<<"cnmlgb1!"<<std::endl;
     std::cout<<"new ID: "<<New_ID<<std::endl;

    while(j <= num_vertices){

      //   std::cout<<"j: "<<j<<std::endl;
         vertex_t src_1 = sorted_ID[j];
         if(!visit[src_1]){
           balanced_sorted_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
           partition_edges += vertices[src_1].out_deg;
        }
        j++;
        if(p < 3 && partition_edges >= sub_edges){

           std::cout<<"cnmlgb3!"<<std::endl;
           std::cout<<"new ID: "<<New_ID<<std::endl;
           break;
       }
     }
     cout << "num of edges in partition "<<p<<": "<<partition_edges<< endl;
    }
    cout << "Largest NewID: " <<New_ID << endl;
    cout << "Finish balancing!" << endl;

}
    

void Balanced_highly_active_edges(){

    vertex_t New_ID = 0;
    vertex_t sub_vertices = num_vertices/2 + 1;
    vertex_t num_active = num_vertices/100 + 1;
    vertex_t sub_active = num_active/2 + 1;
    index_t sub_edges = num_edges/2 + 1;
    index_t num_highly_active_edges = 0;

    for(vertex_t v = 0; v < num_active; v++){

       vertex_t v1 = sorted_ID[v];
       num_highly_active_edges += vertices[v1].out_deg;
    }   

    cout<<"num of highly active edges: "<<num_highly_active_edges<<endl;

    int p = 0;
    int j = num_active;
    int i = 0;
    index_t sub_active_edges = num_highly_active_edges/2;

    for(p; p < 2; p++){

     index_t partition_edges = 0;
     while(i < num_active){

        vertex_t src = sorted_ID[i];
/*      if(visit[src])
           std::cout<<"src: "<<src<<" new id: "<<Map_ID[src]<<std::endl;*/
        if(!visit[src]){
           balanced_sorted_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
           partition_edges += vertices[src].out_deg;
        }
        i++;
        if(p < 1 && partition_edges >= sub_active_edges)

           break;
      }

     cout << "num of highly active edges in partition "<<p<<": "<<partition_edges<< endl;
     std::cout<<"cnmlgb1!"<<std::endl;
     std::cout<<"new ID: "<<New_ID<<std::endl;

    while(j <= num_vertices){

      //   std::cout<<"j: "<<j<<std::endl;
         vertex_t src_1 = sorted_ID[j];
         if(!visit[src_1]){
           balanced_sorted_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
           partition_edges += vertices[src_1].out_deg;
        }
        j++;
        if(p < 1 && partition_edges >= sub_edges){

           std::cout<<"cnmlgb3!"<<std::endl;
           std::cout<<"new ID: "<<New_ID<<std::endl;
           break;
       }
     }
     cout << "num of edges in partition "<<p<<": "<<partition_edges<< endl;
    }
    cout << "Largest NewID: " <<New_ID << endl;
    cout << "Finish balancing!" << endl;

}


void Balanced_activity_vertices(){

    vertex_t New_ID = 0;
    vertex_t sub_vertices = num_vertices/4 + 1;
    vertex_t num_active = num_vertices/100 + 1;
    vertex_t sub_active = num_active/4 + 1;
    int p = 0;
    int j = num_active;

    for(p; p < 4; p++){

//	New_ID = sub_vertices * p;
        for(vertex_t i = sub_active * p; i < sub_active * (p+1); i++){
         vertex_t src = sorted_ID[i];
/*	 if(visit[src])
           std::cout<<"src: "<<src<<" new id: "<<Map_ID[src]<<std::endl;*/
         if(!visit[src]){
           balanced_sorted_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }

      }

      std::cout<<"cnmlgb1!"<<std::endl;
      std::cout<<"new ID: "<<New_ID<<std::endl; 
    
    while(j <= num_vertices){

      //   std::cout<<"j: "<<j<<std::endl;
         vertex_t src_1 = sorted_ID[j];
         if(!visit[src_1]){
           balanced_sorted_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
//	   newid_visit[New_ID] = true;
        }
      /*  for(vertex_t v = 0; v < vertices[src_1].out_neighbor.size(); v++){

           vertex_t out_neb = vertices[src_1].out_neighbor[v];
           if(!visit[out_neb]){
            Map_ID[out_neb] = New_ID;
            Old_ID[New_ID] = out_neb;
            New_ID++;
            visit[out_neb] = true;
        }

      }*/
	j++;
	if(p < 3 && New_ID >= sub_vertices*(p+1)){
	
	   std::cout<<"cnmlgb2!"<<std::endl;
           std::cout<<"new ID: "<<New_ID<<std::endl;
	   break;
       }
     }
    }
    cout << "Largest NewID: " <<New_ID << endl; 
    cout << "Finish balancing!" << endl;

}


void Reordering_hybrid(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices/100; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
      }
     for(vertex_t j = 0; j < num_vertices; j++){

       vertex_t src_1 = sorted_ID[j];
       if(!visit[src_1]){
           Map_ID[src_1] = New_ID;
           Old_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
        }
	for(vertex_t v = 0; v < vertices[src_1].out_neighbor.size(); v++){

           vertex_t out_neb = vertices[src_1].out_neighbor[v];
           if(!visit[out_neb]){
            Map_ID[out_neb] = New_ID;
            Old_ID[New_ID] = out_neb;
            New_ID++;
            visit[out_neb] = true;
        }

      }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_traverse(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_hybrid_balanced(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices/200; i++){
        vertex_t src = balanced_sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
      }
     for(vertex_t j = num_vertices/200; j < num_vertices; j++){

       vertex_t src_1 = balanced_sorted_ID[j];
       if(!visit[src_1]){
           Map_ID[src_1] = New_ID;
           Old_ID[New_ID] = src_1;
           New_ID++;
           visit[src_1] = true;
        }
        for(vertex_t v = 0; v < vertices[src_1].out_neighbor.size(); v++){

           vertex_t out_neb = vertices[src_1].out_neighbor[v];
           if(!visit[out_neb]){
            Map_ID[out_neb] = New_ID;
            Old_ID[New_ID] = out_neb;
            New_ID++;
            visit[out_neb] = true;
        }

      }

     }
     cout << "Finish reordering!" << endl;

}


void Reordering_traverse_balanced(){

     vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = balanced_sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < vertices[src].out_neighbor.size(); j++){

            vertex_t out_neb = vertices[src].out_neighbor[j];
            if(!visit[out_neb]){ 
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void Reordering_activity_balanced(){

    for(vertex_t i =0; i < num_vertices; i++){

        Map_ID[balanced_sorted_ID[i]] = i;
        Old_ID[i] = balanced_sorted_ID[i];

    }

    cout << "Finish reordering!" << endl;

}


void Reordering_activity(){

    for(vertex_t i =0; i < num_vertices; i++){

        Map_ID[sorted_ID[i]] = i;
        Old_ID[i] = sorted_ID[i];

    }

    cout << "Finish reordering!" << endl;

}

/*void Balanced_activity(){

    vertex_t sub_vertices = num_vertices/4;
    vertex_t num_active = num_vertices/100;
    vertex_t sub_active = num_active/4;	

    for(int p =0; p < 4; p++){

        for(vertex_t i = 0; i < sub_active; i++){
       
          balanced_sorted_ID[sub_vertices * p + i] = sorted_ID[sub_active * p + i];

       }

        for(vertex_t j = 0; j < sub_vertices - sub_active; j++){

          balanced_sorted_ID[sub_vertices * p + sub_active + j] = sorted_ID[num_active + j];

       }


    }
}*/

void GenerateNewFile(){

    new_filename = filename + "_reorder";
     FILE* graph_data = fopen(new_filename.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename << endl;
		exit(1);
	}

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

	}

	fclose(graph_data);
	cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}

void GenerateNewFile1(){

    new_filename = filename + "_reorder_act";
     FILE* graph_data = fopen(new_filename.c_str(), "w");
     if(graph_data == NULL){
                cout << "can not open file " << new_filename << endl;
                exit(1);
        }

    size_t num_edges = 0;
    vertex_t old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = Old_ID[i];
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%d %d\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;

        }

        }

        fclose(graph_data);
        cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}


void GenerateNewFile_CSR(){

     new_filename = filename + "_reorder_csr";
     FILE* graph_data = fopen(new_filename.c_str(), "wb");
     if(graph_data == NULL){
                cout << "can not open file " << new_filename << endl;
                exit(1);
        }
     beg_filename = filename + "_beg";
     FILE* beg_file = fopen(beg_filename.c_str(), "wb");
     if(beg_file == NULL){
                cout << "can not open file " << beg_filename << endl;
                exit(1);
        }


    size_t num_edges = 0;
    size_t pos = 0;
    vertex_t new_src, old_src, old_dst, new_dst;

    for(vertex_t i = 0; i < num_vertices; i++){

        old_src = sorted_ID[i];
        new_src = Map_ID[old_src];
	beg_pos[new_src] = pos;
        for(vertex_t j = 0; j < vertices[old_src].out_neighbor.size(); j++){

            old_dst = vertices[old_src].out_neighbor[j];
            new_dst = Map_ID[old_dst];
	    fwrite(&new_dst, sizeof(vertex_t), 1, graph_data);
	 //   fprintf(graph_data, "%ld %ld\n",i,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            num_edges++;
	    pos++;

        }

     }

     fclose(graph_data);
     fwrite(beg_pos, sizeof(index_t), num_vertices, beg_file);
     fclose(beg_file);
     cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;
     cout<<"size of vertex_t:"<< sizeof(vertex_t) << " size of index_t:"<<sizeof(index_t)<<endl;

}


/*void Test(){

    string new_filename_test = filename + "_test";
    FILE* graph_data = fopen(new_filename_test.c_str(), "w");
     if(graph_data == NULL){
		cout << "can not open file " << new_filename_test << endl;
		exit(1);
	}

    for(vertex_t i = 0; i <34681189; i++)

        fprintf(graph_data, "%d %d\n",i,i+1);

}*/

int main(int argc, char **argv){

    printf("Input: ./exe initial_file number_of_vertices\n");
    if(argc != 3){
		printf("Input format wrong\n");
		exit(-1);
	}
    filename = argv[1];
    num_vertices = atoi(argv[2]);

    struct timeval time_st, time_en, time_en1;
    //unsigned * vertex_index;
    //int * in_degree;
    //int * out_degree;

    //vertex_index = new unsigned[num_vertices];
    //in_degree = new int[num_vertices];
    //out_degree = new int[num_vertices];


    vertices = new struct vertex[num_vertices];


    obtain_degree();

   /* for(vertex_t i =0; i < num_vertices; i++){

        for(vertex_t j = 0; j < vertices[i].out_neighbor.size(); j++){

            vertex_t dst = vertices[i].out_neighbor[j];
            cout<<i<<"->"<<dst<<endl;
        }
    } */

    struct timeval time_st2, time_en2;

    gettimeofday(&time_st2, NULL);

    activity = new float[num_vertices];

    compute_activity();

    gettimeofday(&time_en2, NULL);
    float timeuse2 = 1000000 * (time_en2.tv_sec - time_st2.tv_sec) + time_en2.tv_usec - time_st2.tv_usec;
    timeuse2 /= 1000000;
    cout<<"It take "<<timeuse2<<" seconds to compute activity!"<<endl;

 /*   for(vertex_t i =0; i < num_vertices; i++)

        cout<<activity[i]<<endl; */
    sorted_ID = new vertex_t[num_vertices];
    balanced_sorted_ID = new vertex_t[num_vertices];

    for(vertex_t i = 0; i < num_vertices; i++){
        sorted_ID[i] = i;
        balanced_sorted_ID[i] = i;
    }	

//   SortIDByActivity();

   gettimeofday(&time_st, NULL);

   quickSort(sorted_ID, (int)num_vertices);

   /*for(vertex_t i =0; i < num_vertices; i++)

        cout<<sorted_ID[i]<<" "<<activity[sorted_ID[i]]<<endl;*/

    visit = new bool[num_vertices];
//    newid_visit = new bool[num_vertices];

    for(vertex_t j = 0; j < num_vertices; j++){
        visit[j] = false;
        balanced_sorted_ID[j] = sorted_ID[j];
    }
    Map_ID = new vertex_t[num_vertices];
    Old_ID = new vertex_t[num_vertices];

  //  Balanced_highly_active_edges();

    for(vertex_t v = 0; v < num_vertices; v++)
        visit[v] = false;

    Reordering_hybrid();

    cout<<"old to new"<<endl;
    for(vertex_t i =0; i < 10; i++)

        cout<<i<<"->"<<Map_ID[i]<<endl;

    cout<<"new to old"<<endl;
    for(vertex_t i =0; i < 10; i++)

        cout<<i<<"->"<<Old_ID[i]<<endl;
    cout<<endl;

 /*   beg_pos = new index_t[num_vertices];

    for(vertex_t beg = 0; beg < num_vertices; beg++)
        beg_pos[beg] = 0;*/



    gettimeofday(&time_en, NULL);
    float timeuse = 1000000 * (time_en.tv_sec - time_st.tv_sec) + time_en.tv_usec - time_st.tv_usec;
    timeuse /= 1000000;
    cout<<"It take "<<timeuse<<" seconds to reorder!"<<endl;

    GenerateNewFile();
  //  Test();


    return 0;
}
