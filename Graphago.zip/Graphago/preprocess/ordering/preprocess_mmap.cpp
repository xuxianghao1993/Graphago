#include <iostream>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <omp.h>
#include <assert.h>
#include <ctype.h>
#include <algorithm>
#include <sstream>


#define factor 0.00001
#define ISORT 25

using namespace std;
typedef long vertex_t;
typedef long index_t;

const char *filename;
size_t file_size;
char* ss_head;
char* ss;
vertex_t num_vertices, num_edges;
index_t *in_degree;
index_t *out_degree;
index_t *in_index;
index_t *out_index;
vertex_t *CSR;
vertex_t *CSC;
index_t * pos_csc;
int fd_csr, fd_csc;
float *activity;
vertex_t *sorted_ID;
bool *visit;
vertex_t *Map_ID;
vertex_t *Old_ID;


inline off_t fsize(const char *filename) {
    struct stat st;
    if (stat(filename, &st) == 0)
        return st.st_size;
    return -1;
}

void count_vertex(){

         file_size = fsize(filename);
         int fd=open(filename,O_CREAT|O_RDWR,00666 );
         if(fd ==-1) perror("fname open");
         ss_head = (char*)mmap(NULL,file_size,PROT_READ|PROT_WRITE,MAP_SHARED,fd,0);
         close(fd);

         printf("Processing %s, size = %ld\n", filename, file_size);

         size_t head_offset=0;
         while(ss_head[head_offset]=='%' || ss_head[head_offset]=='#'){
               while(ss_head[head_offset]!='\n'){
                     head_offset++;
               }
               head_offset++;
          }
         ss = &ss_head[head_offset];
         file_size -= head_offset;

	 size_t curr=0;
         size_t next=0;

         size_t edge_count=0;
         size_t vert_count;
         vertex_t v_max = 0;
         vertex_t v_min = ((int)1<<30);//as infinity
         vertex_t a;
         while(next < file_size){
              char* sss = ss + curr;
              a = (vertex_t) atol(sss);/* turn initial portion of sss to an integer/long */

              if(v_max<a){
                 v_max = a;
                }
              if(v_min>a){
                 v_min = a;
                }

              if(next >= file_size) break;
              while((ss[next]!=' ')&&(ss[next]!='\n')&&(ss[next]!='\t')){
                                       
		      next++;
                      if(next >= file_size) break;
                   }

              if(next >= file_size) break;
              while((ss[next]==' ')||(ss[next]=='\n')||(ss[next]=='\t')){
                                        
                      next++;
                      if(next >= file_size) break;
                    }
              curr = next;
              edge_count++;
             }
         edge_count /=2;
         cout<<"edge count: "<<edge_count<<endl;
         cout<<"max vertex id: "<<v_max<<endl;
         cout<<"min vertex id: "<<v_min<<endl;
         num_vertices = v_max+1;
	 num_edges = edge_count;
     //  munmap(ss,sizeof(char)*file_size );

}

void obtain_degree(){

	char fname_csr[256];
        sprintf(fname_csr, "%s.csr",filename);
        fd_csr = open(fname_csr,O_CREAT|O_RDWR,00666);
   	if(fd_csr ==-1) perror("fname open");
	assert(ftruncate(fd_csr, num_edges*sizeof(vertex_t)) ==0);
	CSR = (vertex_t*)mmap(NULL,num_edges*sizeof(vertex_t),PROT_READ|PROT_WRITE,MAP_SHARED,fd_csr,0);
	close(fd_csr);

        for(index_t i=0; i<num_edges; i++)
	       CSR[i] = 0;	
	size_t curr=0;
        size_t next=0;
	size_t offset=0;
	vertex_t src, dst;

        while(offset<num_edges){
                                
		char* sss=ss+curr;
                src = (vertex_t) atol(sss);
                while((ss[next]!=' ')&&(ss[next]!='\n')&&(ss[next]!='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }

                while((ss[next]==' ')||(ss[next]=='\n')||(ss[next]=='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                curr = next;

                char* sss1=ss+curr;
                dst = (vertex_t)atol(sss1);
             // cout<<src<<"->"<<dst<<endl;
	        out_degree[src]++;
		in_degree[dst]++;
		CSR[offset] = dst;
                while((ss[next]!=' ')&&(ss[next]!='\n')&&(ss[next]!='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                while((ss[next]==' ')||(ss[next]=='\n')||(ss[next]=='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                curr = next;

                offset++;
                             
        }
	

/*	for(index_t j = 0; j<num_vertices; j++)

	   std::cout<<"vertex:"<<j<<" out_degree: "<<out_degree[j]<<" in_degree:"<<in_degree[j]<<endl;*/
        cout << "Finish obtaining degrees and constructing CSR!" << endl;
 
}

void obtain_csc(){

        char fname_csc[256];
        sprintf(fname_csc, "%s.csc",filename);
        fd_csc = open(fname_csc,O_CREAT|O_RDWR,00666);
        if(fd_csc ==-1) perror("fname open");
        assert(ftruncate(fd_csc, num_edges*sizeof(vertex_t)) ==0);
        CSC = (vertex_t*)mmap(NULL,num_edges*sizeof(vertex_t),PROT_READ|PROT_WRITE,MAP_SHARED,fd_csc,0);
        close(fd_csc);

        for(index_t i=0; i<num_edges; i++)
               CSC[i] = 0;	
        size_t curr=0;
        size_t next=0;
        size_t offset=0;
        vertex_t src, dst;

        while(offset<num_edges){

                char* sss=ss+curr;
                src = (vertex_t) atol(sss);
                while((ss[next]!=' ')&&(ss[next]!='\n')&&(ss[next]!='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }

                while((ss[next]==' ')||(ss[next]=='\n')||(ss[next]=='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                curr = next;

                char* sss1=ss+curr;
                dst = (vertex_t)atol(sss1);
            //  cout<<src<<"->"<<dst<<endl;
	        index_t pos = in_index[dst] + pos_csc[dst];
       	//      cout<<"pos: "<<pos<<endl;
		pos_csc[dst]++;
		CSC[pos] = src;
                
                while((ss[next]!=' ')&&(ss[next]!='\n')&&(ss[next]!='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                while((ss[next]==' ')||(ss[next]=='\n')||(ss[next]=='\t')){
                     //if(next > 409600086) printf("%d\n",(int)ss[next]);
                     next++;
                     //assert(next < file_size);
                }
                curr = next;

                offset++;

        }
     /*   for(index_t j=0; j<num_edges; j++)
		cout<<CSC[j]<<endl;*/
	munmap(ss,sizeof(char)*file_size );

        cout << "Finish constructing CSC!" << endl;

}

void compute_activity(){

      for(vertex_t v = 0; v < num_vertices; v++){

        vertex_t max_indeg = 0;
        for(vertex_t i = 0; i < in_degree[v]; i++){

            vertex_t neb = CSC[in_index[v]+i];
            if(max_indeg < in_degree[neb])
               max_indeg = in_degree[neb];

        }
        if(out_degree[v] == 0)
           activity[v] = -1;
        else if(in_degree[v] == 0)
            activity[v] = 0;
            else
               activity[v] = in_degree[v] * max_indeg * factor;

      }
      cout << "Finish computing activity!" << endl;
      munmap(CSC,sizeof(vertex_t)*num_edges);

}

bool cmp(vertex_t a, vertex_t b){

      return activity[a] > activity[b];
}


//template <class E, class BinPred>
void insertionSort(vertex_t* A, int n) {
    for (int i=0; i < n; i++) {
        vertex_t v = A[i];
        vertex_t* B = A + i;
        while (--B >= A && cmp(v,*B)) *(B+1) = *B;
        *(B+1) = v;
    }
}

//template <class E, class BinPred>
void quickSort(vertex_t* A, int n) {
    if (n < ISORT) insertionSort(A, n);
    else {
        vertex_t p = A[rand() % n]; // Random pivot
        vertex_t* L = A;   // below L are less than pivot
        vertex_t* M = A;   // between L and M are equal to pivot
        vertex_t* R = A+n-1; // above R are greater than pivot
        while (1) {
            while (!cmp(p,*M)) {
                if (cmp(*M,p)) swap(*M,*(L++));
                if (M >= R) break;
                M++;
            }
            while (cmp(p,*R)) R--;
            if (M >= R) break;
            swap(*M,*R--);
            if (cmp(*M,p)) swap(*M,*(L++));
            M++;
        }
        quickSort(A, (int) (L-A));
        quickSort(M, (int) (A+n-M)); // Exclude all elts that equal pivot
    }
}

void Reordering_activity(){

    for(vertex_t i =0; i < num_vertices; i++){

        Map_ID[sorted_ID[i]] = i;
        Old_ID[i] = sorted_ID[i];

    }

    cout << "Finish reordering!" << endl;

}

void Reordering_activity_traverse(){

    vertex_t New_ID = 0;
     for(vertex_t i =0; i < num_vertices - 1; i++){
        vertex_t src = sorted_ID[i];
       if(!visit[src]){
           Map_ID[src] = New_ID;
           Old_ID[New_ID] = src;
           New_ID++;
           visit[src] = true;
        }
        for(vertex_t j = 0; j < out_degree[src]; j++){

            vertex_t out_neb = CSR[out_index[src]+j];
            if(!visit[out_neb]){
               Map_ID[out_neb] = New_ID;
               Old_ID[New_ID] = out_neb;
               New_ID++;
               visit[out_neb] = true;
            }

        }

     }
     cout << "Finish reordering!" << endl;

}

void GenerateNewFile(){

     string fname_reorder;
     fname_reorder = "edgelist_reorder";
  // sprintf(fname_reorder, "%s.reorder",filename);
     FILE* graph_data = fopen(fname_reorder.c_str(), "w");
     if(graph_data == NULL){
                cout << "can not open file " << fname_reorder << endl;
                exit(1);
        }

     size_t edge_count = 0;
     vertex_t new_src, old_src, old_dst, new_dst;

     for(vertex_t i = 0; i < num_vertices; i++){

        old_src = sorted_ID[i];
        new_src = Map_ID[old_src];
        for(vertex_t j = 0; j < out_degree[old_src]; j++){

            old_dst = CSR[out_index[old_src]+j];
            new_dst = Map_ID[old_dst];
            fprintf(graph_data, "%ld %ld\n",new_src,new_dst);


             /* cout<<old_src<<"->"<<old_dst<<endl;
              cout<<new_src<<"->"<<new_dst<<endl;
              cout<<endl;*/
            edge_count++;

        }

      }
        munmap(CSR,sizeof(vertex_t)*num_edges);

        fclose(graph_data);
        cout << "Finish generating new file, total number of edges:"<<num_edges<< endl;

}


int main(int argc, char** argv){

         filename = argv[1];
	 	 
	 count_vertex();

	 in_degree = new index_t[num_vertices];
         out_degree = new index_t[num_vertices];
         for(index_t i=0; i<num_vertices; i++){

		 in_degree[i] =0;
		 out_degree[i] =0;
	 }	 
	
	 obtain_degree();

         in_index = new index_t[num_vertices];
         out_index = new index_t[num_vertices];
         pos_csc = new index_t[num_vertices];
	 for(index_t j=0; j<num_vertices; j++){

	      if(j==0){
		 in_index[j] = 0;
		 out_index[j] = 0;
	      }
              else{
	       in_index[j] = in_index[j-1]+in_degree[j-1];
	       out_index[j] = out_index[j-1]+out_degree[j-1];
              }
	      pos_csc[j] = 0;
          //  cout<<"in_index of "<<j<<": "<<in_index[j]<<endl;
	 }

         obtain_csc();	 

	 free(pos_csc);

	 activity = new float[num_vertices];

	 compute_activity();

	 free(in_degree);
	 free(in_index);

/*	 for(vertex_t i =0; i < num_vertices; i++)

           cout<<activity[i]<<endl;*/

	 sorted_ID = new vertex_t[num_vertices];
         
         for(vertex_t i = 0; i < num_vertices; i++)
             sorted_ID[i] = i;

	 quickSort(sorted_ID, (int)num_vertices);

	 free(activity);

/*	 for(vertex_t i =0; i < num_vertices; i++)

            cout<<sorted_ID[i]<<" "<<activity[sorted_ID[i]]<<endl;*/

         visit = new bool[num_vertices];
         for(vertex_t j = 0; j < num_vertices; j++)
            visit[j] = false;

         Map_ID = new vertex_t[num_vertices];
         Old_ID = new vertex_t[num_vertices];

         Reordering_activity_traverse();

     /*    cout<<"old to new"<<endl;
         for(vertex_t i =0; i < num_vertices; i++)

            cout<<i<<"->"<<Map_ID[i]<<endl;

         cout<<"new to old"<<endl;
         for(vertex_t i =0; i < num_vertices; i++)

            cout<<i<<"->"<<Old_ID[i]<<endl;
         cout<<endl;*/

         GenerateNewFile();

	 return 0;
 }
